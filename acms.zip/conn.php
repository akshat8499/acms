<?php
$conn=mysqli_connect("localhost","akshat","sqlpass
","cms");
?>
