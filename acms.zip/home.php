<HTML>
  <HEAD>
      <link rel="stylesheet" type="text/css" href="cssfile.css">
  </HEAD>
  <BODY>
    <ul>
      <li><a href="home.php" class="active">HOME</a></li>
      <li><a href="allusers.php">VIEW All USERS</a></li>
    </ul>
    <b><h2>WELCOME TO AKSHAT'S CREDITS MANAGEMENT SYSTEM</h2>
    <h4>BELOW ARE INSTRUNCTIONS FOR USING THE System</h4><b>
    <ol>
      <li>View all users</li><br>
      <li>Select the user who wants to send credits</li><br>
      <li>Select the user who will recieve credits</li><br>
      <li>Enter number of credits to be transferred</li><br>
      <li>view all changes to verify changes</li><br>
    </ol>
    <B>THANKS FOR VISITING OUR SITE</B>
  </BODY>
</HTML>
